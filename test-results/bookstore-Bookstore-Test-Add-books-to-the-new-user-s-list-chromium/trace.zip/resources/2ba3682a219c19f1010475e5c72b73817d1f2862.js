(function() {
	(document.createElement('IMG')).src = 'https://ib.adnxs.com/getuid?https://cm.mgid.com/m?cdsp=834104&c=$UID';
	(document.createElement('IMG')).src = 'https://prebid.a-mo.net/cchain/0?gdpr=0&gdpr_consent=&us_privacy=&cb=https%3A//cm.mgid.com/m%3Fcdsp%3D779131%26c%3D';
	(document.createElement('IMG')).src = 'https://cm.rtbsystem.com/mgid?c=p67CKvVTLu9d&gdpr=0&gdpr_consent=&us_privacy=&cd=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D556372%26c%3D%24%7BUSER%7D';
	var d43070 = document.createElement('div');d43070.innerHTML="<iframe id=\"multisync-iframe\" height=\"0\" width=\"0\" marginwidth=\"0\" marginheight=\"0\" scrolling=\"no\" frameborder=\"0\" src=\"https://secure-assets.rubiconproject.com/utils/xapi/multi-sync.html?p=mgid&endpoint=us-west&gdpr=0&gdpr_consent=&us_privacy=\" style=\"border: 0px; display: none;\"></iframe>";document.body.appendChild(d43070);
	(document.createElement('IMG')).src = 'https://sync.adkernel.com/user-sync?zone=219216&t=image&gdpr=0&gdpr_consent=&us_privacy=&r=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834154%26c%3D%7BUID%7D';
	(document.createElement('IMG')).src = 'https://sync.richaudience.com/f7872c90c5d3791e2b51f7edce1a0a5d/?p=1jfI3wDKNj&consentString=[consentString]&r=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834139%26c%3D%5BPDID%5D';
	var d834098 = document.createElement('div');d834098.innerHTML="<iframe src=\"https://onetag-sys.com/usync/?pubId=7cd9d7c7c13ff36&sync_id=p67CKvVTLu9d&gdpr=0&gdpr_consent=&us_privacy=\" style=\"display: none;\"></iframe>";document.body.appendChild(d834098);
	(document.createElement('IMG')).src = 'https://match.360yield.com/match?external_user_id=p67CKvVTLu9d&publisher_dsp_id=489&dsp_callback=1&&gdpr=0&gdpr_consent=&r=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834124%26c%3D%7BPUB_USER_ID%7D';
	(document.createElement('IMG')).src = 'https://b1sync.zemanta.com/usersync/mgid/?puid=p67CKvVTLu9d&gdpr=0&gdpr_consent=&us_privacy=&cb=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834142%26c%3D%7Buser_id%7D';
	(document.createElement('IMG')).src = 'https://creativecdn.com/cm-notify?pi=mgid&gdpr=0&gdpr_consent=&us_privacy=';
})()

(function() {
	var d43070 = document.createElement('div');d43070.innerHTML="<iframe id=\"multisync-iframe\" height=\"0\" width=\"0\" marginwidth=\"0\" marginheight=\"0\" scrolling=\"no\" frameborder=\"0\" src=\"https://secure-assets.rubiconproject.com/utils/xapi/multi-sync.html?p=mgid&endpoint=us-west&gdpr=0&gdpr_consent=&us_privacy=\" style=\"border: 0px; display: none;\"></iframe>";document.body.appendChild(d43070);
	(document.createElement('IMG')).src = 'https://ad.360yield.com/server_match?partner_id=1944&gdpr=0&gdpr_consent=&us_privacy=&r=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D665953%26c%3D%7BPUB_USER_ID%7D';
	var d834098 = document.createElement('div');d834098.innerHTML="<iframe src=\"https://onetag-sys.com/usync/?pubId=7cd9d7c7c13ff36&sync_id=p67WZBg-i3yc&gdpr=0&gdpr_consent=&us_privacy=\" style=\"display: none;\"></iframe>";document.body.appendChild(d834098);
	(document.createElement('IMG')).src = 'https://ap.lijit.com/pixel?gdpr=0&gdpr_consent=&redir=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D709070%26c%3D%24UID';
	(document.createElement('IMG')).src = 'https://prebid.a-mo.net/cchain/0?gdpr=0&gdpr_consent=&us_privacy=&cb=https%3A//cm.mgid.com/m%3Fcdsp%3D779131%26c%3D';
})()

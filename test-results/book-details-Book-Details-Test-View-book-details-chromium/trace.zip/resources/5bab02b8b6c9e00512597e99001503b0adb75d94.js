(function() {
	(document.createElement('IMG')).src = 'https://sync.crwdcntrl.net/qmap?c=14777&tp=MIGD&tpid=p67F5ZfQSK6d&gdpr=0&gdpr_consent=';
	(document.createElement('IMG')).src = 'https://ap.lijit.com/pixel?gdpr=0&gdpr_consent=&redir=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D709070%26c%3D%24UID';
	(document.createElement('IMG')).src = 'https://ib.adnxs.com/getuid?https://cm.mgid.com/m?cdsp=834104&c=$UID';
	(document.createElement('IMG')).src = 'https://cm.rtbsystem.com/mgid?c=p67F5ZfQSK6d&gdpr=0&gdpr_consent=&us_privacy=&cd=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D556372%26c%3D%24%7BUSER%7D';
	(document.createElement('IMG')).src = 'https://prebid.a-mo.net/cchain/0?gdpr=0&gdpr_consent=&us_privacy=&cb=https%3A//cm.mgid.com/m%3Fcdsp%3D779131%26c%3D';
	(document.createElement('IMG')).src = 'https://cm.g.doubleclick.net/pixel?google_nid=marketgid&google_cm=&google_ula={guid}&google_hm=cDY3RjVaZlFTSzZk&muidn=p67F5ZfQSK6d&gdpr=0&gdpr_consent=';
	(document.createElement('IMG')).src = 'https://sync.adkernel.com/user-sync?zone=219216&t=image&gdpr=0&gdpr_consent=&us_privacy=&r=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834154%26c%3D%7BUID%7D';
	var d43070 = document.createElement('div');d43070.innerHTML="<iframe id=\"multisync-iframe\" height=\"0\" width=\"0\" marginwidth=\"0\" marginheight=\"0\" scrolling=\"no\" frameborder=\"0\" src=\"https://secure-assets.rubiconproject.com/utils/xapi/multi-sync.html?p=mgid&endpoint=us-west&gdpr=0&gdpr_consent=&us_privacy=\" style=\"border: 0px; display: none;\"></iframe>";document.body.appendChild(d43070);
	(document.createElement('IMG')).src = 'https://cm.idealmedia.io/i.gif?muidf=p67F5ZfQSK6d&gdpr=0&gdpr_consent=&us_privacy=';
	(document.createElement('IMG')).src = 'https://sync.richaudience.com/f7872c90c5d3791e2b51f7edce1a0a5d/?p=1jfI3wDKNj&consentString=[consentString]&r=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834139%26c%3D%5BPDID%5D';
	(document.createElement('IMG')).src = 'https://image8.pubmatic.com/AdServer/ImgSync?p=161673&gdpr=0&gdpr_consent=&pu=https%3A%2F%2Fimage4.pubmatic.com%2FAdServer%2FSPug%3FpartnerID%3D161673%26pmc%3DPM_PMC%26pr%3Dhttps%253A%252F%252Fcm.mgid.com%252Fm%253Fcdsp%253D712807%2526c%253D%2523PMUID';
	var d834098 = document.createElement('div');d834098.innerHTML="<iframe src=\"https://onetag-sys.com/usync/?pubId=7cd9d7c7c13ff36&sync_id=p67F5ZfQSK6d&gdpr=0&gdpr_consent=&us_privacy=\" style=\"display: none;\"></iframe>";document.body.appendChild(d834098);
	(document.createElement('IMG')).src = 'https://match.360yield.com/match?external_user_id=p67F5ZfQSK6d&publisher_dsp_id=489&dsp_callback=1&&gdpr=0&gdpr_consent=&r=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834124%26c%3D%7BPUB_USER_ID%7D';
	(document.createElement('IMG')).src = 'https://ps.eyeota.net/match?bid=dn2m51u&uid=p67F5ZfQSK6d&gdpr=0&gdpr_consent=';
	(document.createElement('IMG')).src = 'https://ssbsync.smartadserver.com/api/sync?callerId=155&gdpr=0&gdpr_consent=&url=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834126%26c%3D%5Bsas_sync_pid%5D%26nwid%3D4577';
	(document.createElement('IMG')).src = 'https://b1sync.zemanta.com/usersync/mgid/?puid=p67F5ZfQSK6d&gdpr=0&gdpr_consent=&us_privacy=&cb=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834142%26c%3D%7Buser_id%7D';
	(document.createElement('IMG')).src = 'https://ad.360yield.com/server_match?partner_id=1944&gdpr=0&gdpr_consent=&us_privacy=&r=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D665953%26c%3D%7BPUB_USER_ID%7D';
	(document.createElement('IMG')).src = 'https://creativecdn.com/cm-notify?pi=mgid&gdpr=0&gdpr_consent=&us_privacy=';
})()
